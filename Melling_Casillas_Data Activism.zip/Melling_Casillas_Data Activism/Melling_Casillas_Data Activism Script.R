install.packages("stringr")
install.packages("tidyverse")
install.packages("corrplot")
install.packages("RColorBrewer")
library(stringr)
library(tidyverse)
library(readr)
library(corrplot)
library(RColorBrewer)
library(ggplot2)

index <- read.csv(file = 'index.csv')

# Population Density

child_pop <- index$pop
education_z <- index$z_ED_nat
socioeconomic_z <- index$z_SE_nat
health_z <- index$z_HE_nat
overall_z <- index$z_COI_nat
population_z <- data.frame(child_pop,education_z,socioeconomic_z,health_z,overall_z)
M <-cor(population_z)
corrplot(M, type = "full")
cor(population_z)

# National Rankings of z scores (standard deviation/mean of education [ED], health and environment [HE],
# and social and economic [SE]) against the levels of overall opportunity within the nation.

ggplot(index, aes(z_COI_nat, c5_COI_nat)) + 
  geom_point(color = "blue") + 
  stat_summary(fun.y = "mean", geom = "line",
               size = 1, linetype = "dashed") +
  labs(title="Overall Child Opportunity, nationally normed",
       x ="Z-score", y = "Levels")


# State Rankings of domains scored (standard deviation/mean of education [ED], health and environment [HE],
# and social and economic [SE]) against the levels of overall opportunity within the state.

index_state2 <- filter(index, stateusps == "MI", year == "2015")
index_state2

## Health and Environment

index_state2$Level <- as.factor(index_state2$c5_COI_stt)

ggplot(index_state2, aes(x=r_COI_stt, y=r_HE_stt, shape=Level, alpha=Level, size=Level, color=Level)) +
  geom_point(size = 3) +
  labs(title="Child Opportunity, state normed: Michigan 2015",
       x="Overall Scores", y="Health and Environment")

## Education

ggplot(index_state2, aes(x=r_COI_stt, y=r_ED_stt, shape=Level, alpha=Level, size=Level, color=Level)) +
  geom_point(size = 3) +
  labs(title="Child Opportunity, state normed: Michigan 2015",
       x="Overall Scores", y="Education")

## Social and Economic

ggplot(index_state2, aes(x=r_COI_stt, y=r_SE_stt, shape=Level, alpha=Level, size=Level, color=Level)) +
  geom_point(size = 3) +
  labs(title="Child Opportunity, state normed: Michigan 2015",
       x="Overall Scores", y="Social and Economic")

# Metro Rankings of domains scored (standard deviation/mean of education [ED], health and environment [HE],
# and social and economic [SE]) against the levels of overall opporunity within the city of Detroit, MI.

index_met <- filter(index_state2, msaname15 == "Detroit-Warren-Dearborn, MI Metro Area")
index_met

## Health and Environment

ggplot(index_met, aes(x=r_COI_met, y=r_HE_met, shape=Level, alpha=Level, size=Level, color=Level)) +
  geom_point(size = 3) +
  labs(title="Child Opportunity, state normed: Detroit, Michigan 2015",
       x="Overall Scores", y="Health and Environment")

## Education

ggplot(index_met, aes(x=r_COI_met, y=r_ED_met, shape=Level, alpha=Level, size=Level, color=Level)) +
  geom_point(size = 3) +
  labs(title="Child Opportunity, state normed: Detroit, Michigan 2015",
       x="Overall Scores", y="Education")

## Social and Economic

ggplot(index_met, aes(x=r_COI_met, y=r_SE_met, shape=Level, alpha=Level, size=Level, color=Level)) +
  geom_point(size = 3) +
  labs(title="Child Opportunity, state normed: Detroit, Michigan 2015",
       x="Overall Scores", y="Social and Economic")
